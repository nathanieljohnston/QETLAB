%%  PURITY    Computes the purity of a quantum state
%   This function has one required argument:
%     RHO: a density matrix
%
%   GAMMA = Purity(RHO) is the purity of the quantum state RHO (i.e., GAMMA
%   is the quantity trace(RHO^2)).
%
%   URL: http://www.qetlab.com/Purity

%   requires: nothing
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.00
%   last updated: July 18, 2013

function gamma = Purity(rho)

gamma = trace(rho^2);