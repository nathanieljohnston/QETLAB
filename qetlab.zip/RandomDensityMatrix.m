%%  RANDOMDENSITYMATRIX    Generates a random density matrix
%   This function has one required argument:
%     DIM: the number of rows (and columns) of the density matrix
%
%   RHO = RandomDensityMatrix(DIM) generates a random DIM-by-DIM density
%   matrix, distributed according to the Hilbert-Schmidt measure.
%
%   This function has three optional arguments:
%     RE (default 0)
%     K (default DIM)
%     DIST (default 'hs')
%
%   RHO = RandomDensityMatrix(DIM,RE,K,DIST) generates a random density
%   matrix of rank <= K, distributed according to the distribution DIST. If
%   RE = 1 then all of its entries will be real. DIST must be one of:
%     'hs' (default) - the Hilbert-Schmidt measure
%     'bures'        - the Bures measure
%     'haar'         - generate a larger  pure state according to Haar
%                      measure and trace out the extra dimensions
%
%   URL: http://www.qetlab.com/RandomDensityMatrix

%   requires: MaxEntangled.m, opt_args.m, PartialTrace.m, PermuteSystems.m,
%             RandomStateVector.m, RandomUnitary.m, Swap.m
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.00
%   last updated: November 23, 2012

function rho = RandomDensityMatrix(dim,varargin)

% set optional argument defaults: re=0, k=dim, dist='hs'
[re,k,dist] = opt_args({ 0, dim, 'hs' },varargin{:});

% Haar measure
if(strcmpi(dist,'haar'))
    phi = RandomStateVector(dim*k,re);
    rho = PartialTrace(phi*phi',1,[k,dim]);
    
% Hilbert-Schmidt or Bures measure
else
    gin = randn(dim,k);
    if(~re)
        gin = gin + 1i*randn(dim,k);
    end
    if(strcmpi(dist,'bures')) % Bures measure
        gin = (RandomUnitary(dim,re) + eye(dim))*gin;
    end

    rho = gin*gin';
    rho = rho/trace(rho);
end