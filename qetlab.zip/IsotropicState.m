%%  ISOTROPICSTATE    Produces an isotropic state
%   This function has two required arguments:
%     DIM: the local dimension
%     ALPHA: the parameter of the isotropic state
%
%   RHO = IsotropicState(DIM,ALPHA) is the isotropic state with parameter
%   ALPHA acting on (DIM*DIM)-dimensional space. More specifically, RHO is
%   the density operator defined by (1-ALPHA)*I/DIM^2 + ALPHA*E, where I is
%   the identity operator and E is the projection onto the standard
%   maximally-entangled pure state on two copies of DIM-dimensional space.
%
%   This function has one optional argument:
%     SP (default 0)
%   
%   RHO = IsotropicState(DIM,ALPHA,SP) produces an isotropic state as above
%   that is sparse if SP = 1 and is full if SP = 0.
%
%   URL: http://www.qetlab.com/IsotropicState

%   requires: iden.m, MaxEntangled.m, opt_args.m
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.00
%   last updated: January 7, 2013

function rho = IsotropicState(dim,alpha,varargin)

% set optional argument defaults: sp=0
[sp] = opt_args({ 0 },varargin{:});

% compute the isotropic state
psi = MaxEntangled(dim,sp,0);
rho = (1-alpha)*iden(dim^2,sp)/dim^2 + alpha*psi*psi'/dim;