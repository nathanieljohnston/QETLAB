%%  TRACENORM  Computes the trace norm of an operator
%   This function has one required argument:
%     X: an operator
%
%   NRM = TraceNorm(X) is the trace norm of X.
%
%   URL: http://www.qetlab.com/TraceNorm

%   requires: kpNorm.m
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.00
%   last updated: December 1, 2012

function nrm = TraceNorm(X)

nrm = kpNorm(X,min(size(X)),1);