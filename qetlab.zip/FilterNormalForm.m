%%  FILTERNORMALFORM    Computes the filter normal form of an operator
%   This function has one required argument:
%     RHO: a density matrix
%
%   XI = FilterNormalForm(RHO) is a vector of the coefficients in RHO's
%   filter normal form (see Section IV.D of [1]), which are useful for
%   showing that RHO is entangled.
%
%   The filter normal form is not guaranteed to exist if RHO is not full
%   rank. If a filter normal form can not be found, an error is returned.
%
%   This function has two optional input arguments:
%     DIM (default has both subsystems of equal dimension)
%     TOL (default sqrt(eps))
%
%   This function has four optional output arguments:
%     GA,GB: cells of mutually orthonormal matrices
%     FA,FB: invertible matrices
%
%   [XI,GA,GB,FA,FB] = FilterNormalForm(RHO,DIM,TOL) returns XI, GA, GB,
%   FA, FB such that (eye(length(RHO)) + TensorSum(XI,GA,GB))/length(RHO)
%   equals kron(FA,FB)*RHO*kron(FA,FB)'. In other words, FA and FB are
%   matrices implementing the local filter, XI is a vector of coefficients
%   in the filter normal form, and GA and GB are cells of matrices in the
%   tensor-sum decomposition of the filter normal form.
%
%   DIM is a 1-by-2 vector containing the dimensions of the subsystems on
%   which RHO acts. TOL is the numerical tolerance used when constructing
%   the filter normal form.
%
%   URL: http://www.qetlab.com/FilterNormalForm
%
%   References:
%   [1] O. Gittsovich, O. G�hne, P. Hyllus, and J. Eisert. Unifying several
%   separability conditions using the covariance matrix criterion. Phys.
%   Rev. A, 78:052319, 2008. E-print: arXiv:0803.0757 [quant-ph]

%   requires: OperatorSchmidtDecomposition.m, opt_args.m, PartialTrace.m,
%             PermuteSystems.m, SchmidtDecomposition.m, Swap.m
%             
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.02
%   last updated: September 17, 2013

function [xi,GA,GB,FA,FB] = FilterNormalForm(rho,varargin)

lrho = length(rho);

% set optional argument defaults: dim=sqrt(length(rho)), tol=sqrt(eps)
[dim,tol] = opt_args({ round(sqrt(lrho)), sqrt(eps) },varargin{:});

% allow the user to enter a single number for dim
if(length(dim) == 1)
    dim = [dim,lrho/dim];
    if abs(dim(2) - round(dim(2))) >= 2*lrho*eps
        error('FilterNormalForm:InvalidDim','If DIM is a scalar, it must evenly divide length(RHO); please provide the DIM array containing the dimensions of the subsystems.');
    end
    dim(2) = round(dim(2));
end

% start the filtering iteration
rhoa = eye(dim(1))/dim(1);
rhob = eye(dim(2))/dim(2);
FA = eye(dim(1));
FB = eye(dim(2));

% iterate eigenvalues and basis
it_err = 1;
while it_err > tol
    % First, compute X and the basis for the A subsystem
    X = PartialTrace(rho*kron(eye(dim(1)),rhob),2,dim);
    [UX,eigX] = eig(X);
    [eigX,ord] = sort(real(diag(eigX)),'descend');
    UX = UX(:,ord);
    eigrhoa = sort(real(eig(rhoa)));

    % Now iteratively find the proper eigenvalues
    ev_err = 1;
    eigrhoa2 = zeros(dim(1),1);
    while ev_err > tol
        for j=1:dim(1)
            eigrhoa2(j) = sqrt((eigX'*eigrhoa-eigX(j)*eigrhoa(j))/prod(eigrhoa([1:j-1,j+1:dim(1)])));
        end
        eigrhoa2 = sort(eigrhoa2)/sum(eigrhoa2);
        ev_err = norm(eigrhoa-eigrhoa2);
        eigrhoa = eigrhoa2;
    end

    % Now update rhoa
    rhoa2 = UX*diag(eigrhoa)*UX';
    it_err = norm(rhoa-rhoa2);
    rhoa = (rhoa2+rhoa2')/2;
            
    % We now do the same thing for rhob: start by computing X and the basis
    % for the B subsystem
    X = PartialTrace(rho*kron(rhoa,eye(dim(2))),1,dim);
    [UX,eigX] = eig(X);
    [eigX,ord] = sort(real(diag(eigX)),'descend');
    UX = UX(:,ord);
    eigrhob = sort(real(eig(rhob)));

    % Now iteratively find the proper eigenvalues
    ev_err = 1;
    eigrhob2 = zeros(dim(2),1);
    while ev_err > tol
        for j=1:dim(2)
            eigrhob2(j) = sqrt((eigX'*eigrhob-eigX(j)*eigrhob(j))/prod(eigrhob([1:j-1,j+1:dim(2)])));
        end
        eigrhob2 = sort(eigrhob2)/sum(eigrhob2);
        ev_err = norm(eigrhob-eigrhob2);
        eigrhob = eigrhob2;
    end

    % Now update rhob
    rhob2 = UX*diag(eigrhob)*UX';
    it_err = it_err + norm(rhob-rhob2);
    rhob = (rhob2+rhob2')/2;

    % Finally, apply the filter
    TA = sqrtm(rhoa);
    TB = sqrtm(rhob);
    FA = TA*FA;
    FB = TB*FB;
    T = kron(TA,TB);
    rho = T*rho*T';
    tr4 = sqrt(sqrt(trace(rho)));
    rho = rho/tr4^4;
    FA = FA/tr4;
    FB = FB/tr4;
end

% Make sure that the local transformation performed is invertible --
% otherwise, it may not preserve separability/Schmidt number, and thus
% becomes useless for most of our purposes.
if(cond(FA) >= 1/eps || cond(FB) >= 1/eps)
    error('FilterNormalForm:NoFNF','The state RHO can not be transformed into a filter normal form. This is often the case if RHO is not of full rank.');
end

% Do some post-processing to make the output more useful and consistent
% with the literature.
[xi,GA,GB] = OperatorSchmidtDecomposition(rho,dim);

% Remove the identity from the operator Schmidt decomposition.
sj = 0;
pD = prod(dim);
for j = 1:length(xi)
    if(norm(abs(GA{j}/norm(GA{j})) - eye(dim(1))) < 100*pD*tol && norm(abs(GB{j}/norm(GB{j})) - eye(dim(2))) < 100*pD*tol)
        sj = j;
        break;
    end
end
if(sj == 0)
    error('FilterNormalForm:NoFNF','The state RHO can not be transformed into a filter normal form. This is often the case if RHO is not of full rank. If you believe this is a mistake, try increasing TOL.');
end
ind = [1:sj-1,sj+1:length(xi)];
xi = prod(dim)*xi(ind);
GA = GA(ind);
GB = GB(ind);