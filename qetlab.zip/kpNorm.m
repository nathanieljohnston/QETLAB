%%  KPNORM    Computes the (k,p)-norm of a vector or matrix
%   This function has three required arguments:
%     X: a vector or matrix
%     K: a positive integer
%     P: a real number >= 1, or Inf
%
%   NRM = kpNorm(X,K,P) is the P-norm of the vector of the K largest
%   elements of the vector X (if X is a vector), or the P-norm of the
%   vector of the K largest singular values of X (if X is a matrix).
%
%   URL: http://www.qetlab.com/kpNorm

%   requires: nothing
%   author: Nathaniel Johnston (nathaniel@njohnston.ca)
%   version: 1.02
%   last updated: March 9, 2013

function nrm = kpNorm(X,k,p)

sX = size(X);
nX = min(sX);
xX = max(sX);

% If the requested norm is the Frobenius norm, compute it using MATLAB's
% built-in Frobenius norm calculation, which is significantly faster than
% computing singular values.
if((nX > 1 && k >= nX) && p == 2)
    nrm = norm(X,'fro');
    
% That's the one and only special case though; otherwise just compute the
% norm from the singular values.
else
    % p = Inf corresponds to the operator norm, which is calculated faster
    % via k = p = 1.
    if(p == Inf)
        k = 1;
        p = 1;
    end
    
    % Try to determine which method will be faster for computing k singular
    % values: svds (best if X is sparse and k is small) or svd (best if k
    % is large and/or X is full).
    adj = 20 + 1000*(~issparse(X));

    if(nX == 1)
        s = sort(X,'descend');
        s = s(1:min(k,xX));
    elseif(k <= ceil(nX/adj))
        s = svds(X,k);
    else
        s = svd(full(X));
        s = s(1:min(k,nX));
    end
    nrm = norm(s,p);
end